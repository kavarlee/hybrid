import { Component, OnInit } from '@angular/core';
import { DataTransferService } from '../data-transfer.service';

@Component({
  selector: 'app-details',
  templateUrl: './details.page.html',
  styleUrls: ['./details.page.scss'],
})
export class DetailsPage implements OnInit {

  
  constructor(private msgServ : DataTransferService) { }
  myMsg!: any;
  ngOnInit() {
    this.msgServ.asObserver.subscribe(
      message => { this.myMsg = message }); 
  }
  newMessage() {this.msgServ.setMessage(this.myMsg);}
  sendMessage() {
    if (this.myMsg.trim() !== '') { 
      this.msgServ.setMessage(this.myMsg);
      this.myMsg = ''; 
    }
    

  }

}
