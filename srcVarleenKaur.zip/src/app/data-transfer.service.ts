import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable, map } from 'rxjs';
import { WeeklyActivityAssessment } from './Object';
import { CovidData } from './Object';
interface CumulativeDeaths {
  id: number;
  date: string;
  cum_deaths_new_methodology: number;
}
@Injectable({
  providedIn: 'root'
})

export class DataTransferService {
  private canada ='assets/cumulative.deaths.json';
  private ontario='assets/csvjson.json';
  private covidDataUrl = 'assets/covid19-download.json';
  constructor(private http : HttpClient) { }
  getCanadaJson() : Observable<any>{
    return this.http.get<any>(this.canada);
  }
  getCovidData(): Observable<CovidData[]> {
    return this.http.get<CovidData[]>(this.covidDataUrl);
  }

  getOntarioJson(): Observable<WeeklyActivityAssessment[]> {
    return this.http.get<WeeklyActivityAssessment[]>(this.ontario);
  }

  getWeeklyData(startDate: string): Observable<WeeklyActivityAssessment | null> {
    console.log('Fetching data for start date:', startDate);
    return this.http.get<WeeklyActivityAssessment[]>(this.ontario).pipe(
      map((data: WeeklyActivityAssessment[]) =>
        data.find(item => item['Week start date'] === startDate) || null
      )
    );
  }
  getLastEntry(): Observable<WeeklyActivityAssessment | undefined> {
    return this.getOntarioJson().pipe(
      map((data: WeeklyActivityAssessment[]) =>
        data.length > 0 ? data[data.length - 1] : undefined
      )
    );
  }
  message = new BehaviorSubject<any>('');
  asObserver = this.message.asObservable();
  setMessage(msg: any) {
  this.message.next(msg);
  }


} 

