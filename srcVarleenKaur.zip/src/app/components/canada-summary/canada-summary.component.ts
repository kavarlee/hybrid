import { Component, OnInit } from '@angular/core';
import { CovidData } from 'src/app/Object';
import { DataTransferService } from 'src/app/data-transfer.service';

@Component({
  selector: 'app-canada-summary',
  templateUrl: './canada-summary.component.html',
  styleUrls: ['./canada-summary.component.scss'],
})
export class CanadaSummaryComponent  implements OnInit {
  weeklyData: any;
  cumulativeDeathsData: any;
  covidData: CovidData[] = [];
  aggregatedData: any = {};
  constructor(private serv:  DataTransferService) { }

  ngOnInit() {
    this.serv.getCovidData().subscribe((data: CovidData[]) => {
      this.covidData = data;
      this.aggregateData();
    });
  }
  aggregateData() {
    this.aggregatedData.totalCases = this.covidData.reduce((sum, item) => sum + item.totalcases, 0);
    this.aggregatedData.casesToday = this.covidData.reduce((sum, item) => sum + parseInt(item.numtotal_last7), 0);
    this.aggregatedData.totalDeaths = this.covidData.reduce((sum, item) => sum + item.numdeaths, 0);
    this.aggregatedData.deathsToday = this.covidData.reduce((sum, item) => sum + item.numdeaths_last7, 0);
    this.aggregatedData.activeCases = this.aggregatedData.totalCases - this.aggregatedData.totalDeaths; 
    this.aggregatedData.recoveredCases = this.covidData.reduce((sum, item) => sum + parseInt(item.numtotal_last14, 10), 0) - this.aggregatedData.totalDeaths;
    this.aggregatedData.avgIncidenceLast7 = this.covidData.reduce((sum, item) => sum + parseFloat(item.avgincidence_last7), 0) / this.covidData.length;
    this.aggregatedData.avgCasesLast7 = this.covidData.reduce((sum, item) => sum + parseFloat(item.avgcases_last7), 0) / this.covidData.length;
    this.aggregatedData.avgDeathsLast7 = (this.covidData.reduce((sum, item) => sum + item.avgdeaths_last7, 0) / this.covidData.length).toFixed(2);
    this.aggregatedData.avgRateDeathsLast7 = (this.covidData.reduce((sum, item) => sum + item.avgratedeaths_last7, 0) / this.covidData.length).toFixed(2);
  }
}

