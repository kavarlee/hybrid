import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { WeeklyActivityAssessment } from 'src/app/Object';
import { DataTransferService } from 'src/app/data-transfer.service';

@Component({
  selector: 'app-ontario-summary',
  templateUrl: './ontario-summary.component.html',
  styleUrls: ['./ontario-summary.component.scss'],
})
export class OntarioSummaryComponent  implements OnInit {
  aggregatedData: WeeklyActivityAssessment | undefined;
  
  constructor(private dataService: DataTransferService, private router: Router) { }

  ngOnInit() {
    this.fetchLastEntry();
    
  }
  fetchLastEntry(): void {
    this.dataService.getLastEntry()
      .subscribe(data => {
        this.aggregatedData = data;
      });
  }
  
}
