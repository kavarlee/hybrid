import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { WeeklyActivityAssessment } from 'src/app/Object';
import { DataTransferService } from 'src/app/data-transfer.service';

@Component({
  selector: 'app-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.scss'],
})
export class ListComponent  implements OnInit {
  items: WeeklyActivityAssessment[] = [];
  myMsg!: any;
  constructor(private dataService: DataTransferService, private router: Router) { }

  ngOnInit() {
    this.dataService.getOntarioJson().subscribe((data: WeeklyActivityAssessment[]) => {
      this.items = data;
    });
    this.dataService.asObserver.subscribe(
      { next:(message) => { this.myMsg = message; },
      error:(err)=> { console.log(`Error is ${err}.`);},
      complete:()=> { console.log('Done'); } } ) 
    }
  
  openDetails(startDate: string): void {
    this.router.navigate(['/details', startDate]);
  }

}
