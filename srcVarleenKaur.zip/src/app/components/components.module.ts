import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CanadaSummaryComponent } from './canada-summary/canada-summary.component';
import { OntarioSummaryComponent } from './ontario-summary/ontario-summary.component';
import { IonicModule } from '@ionic/angular';
import { FormsModule } from '@angular/forms';
import { ListComponent } from './list/list.component';
import { SelectedWeekComponent } from './selected-week/selected-week.component';
import { RouterModule } from '@angular/router';



@NgModule({
  declarations: [CanadaSummaryComponent,OntarioSummaryComponent,ListComponent,SelectedWeekComponent],
  imports: [
    CommonModule, IonicModule, FormsModule, RouterModule
  ],
  exports:[
    CanadaSummaryComponent,
    OntarioSummaryComponent,
    ListComponent,
    SelectedWeekComponent
  ]
})
export class ComponentsModule { }
