import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { WeeklyActivityAssessment } from 'src/app/Object';
import { DataTransferService } from 'src/app/data-transfer.service';

@Component({
  selector: 'app-selected-week',
  templateUrl: './selected-week.component.html',
  styleUrls: ['./selected-week.component.scss'],
})
export class SelectedWeekComponent  implements OnInit {
  weekStartDate!: string;
  aggregatedData: WeeklyActivityAssessment | null = null;

  constructor(private activatedRoute: ActivatedRoute,
    private dataService: DataTransferService,
  private router: Router) { }

  ngOnInit() {
    this.activatedRoute.params.subscribe((params) => {
      this.weekStartDate = params['weekStartDate'];
      this.loadWeeklyData(this.weekStartDate);
    });
  }
  loadWeeklyData(startDate: string): void {
    this.dataService.getWeeklyData(startDate).subscribe((data) => {
      if (data) {
        this.aggregatedData = data;
      } else {
        console.log('Data not found for start date:', startDate);
        this.aggregatedData = null;
      }
    }, (error) => {
      console.error('Error fetching data:', error);
    });
  }
}
