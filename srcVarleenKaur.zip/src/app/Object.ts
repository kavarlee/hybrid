export interface WeeklyActivityAssessment {
    Indicator: string;
    "Week start date": string;
    "Week end date": string;
    "Surveillance period": string;
    "Surveillance week": number;
    "COVID-19 activity": string;
    "COVID-19 weekly indicator change": string;
    "Influenza activity": string;
    "Influenza weekly indicator change": string;
  }
  
export interface CovidData {
    pruid: number;
    prname: string;
    prnameFR: string;
    date: string;
    reporting_week: number;
    reporting_year: number;
    update: number;
    totalcases: number;
    numtotal_last7: string;
    ratecases_total: string;
    numdeaths: number;
    numdeaths_last7: number;
    ratedeaths: number;
    ratecases_last7: string;
    ratedeaths_last7: number;
    numtotal_last14: string;
    numdeaths_last14: number;
    ratetotal_last14: string;
    ratedeaths_last14: number;
    avgcases_last7: string;
    avgincidence_last7: string;
    avgdeaths_last7: number;
    avgratedeaths_last7: number;
  }